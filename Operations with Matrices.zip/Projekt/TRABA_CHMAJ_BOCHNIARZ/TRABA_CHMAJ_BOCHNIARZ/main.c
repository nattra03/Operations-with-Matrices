#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include "projekt.h"


void menu();

int main() {

	menu();
	return 0;
}
void menu() {
	printf("Operacje na macierzach - spis tresci: \n");
	printf("1. Generowanie macierzy liczbami z przedzialu <-25,25> \n");
	printf("2. Najwieksze wartosci w macierzy \n");
	printf("3. Obliczanie wyznacznika macierzy \n");
	printf("4. Obliczanie liczby wystapien danej liczby w macierzy \n");
	printf("5. Zerowanie przekatnych macierzy \n");
	printf("6. Transpozycja macierzy \n");
	printf("7. Mnozenie macierzy przez wektor \n");
	printf("8. Mnozenie dwoch wektorow \n");
	printf("9. Mnozenie dwoch macierzy \n");
	printf("10. Rownanie macierzowe \n");
	printf("11. Wartosci wlasne macierzy \n");
	printf("12. Wyznaczanie macierzy odwrotnej \n");
	printf("Wybierz co chcesz obliczyc: ");

	int w = 0;
	if (scanf_s("%d", &w) < 1) {
		printf("Niepoprawne dane!");
		return;
	}
	switch (w) {
	case 1:
		wypelnianie_macierzy_test();
		break;
	case 2:
		najwiekszy_element_test();
		break;
	case 3:
		wyznacznik_macierzy_test();
		break;
	case 4:
		liczba_wystapien_test();
		break;
	case 5:
		zerowanie_test();
		break;
	case 6:
		transpose_matrix_test();
		break;
	case 7:
		mnozenie_przez_wektor_test();
		break;
	case 8:
		mnozenie_dwoch_wektorow_test();
		break;
	case 9:
		mnozenie_dwoch_macierzy_test();
		break;
	case 10:
		test_rownanie_macierzowe();
		break;
	case 11:
		test_wartosci_wlasne();
		break;
	case 12:
		test_macierz_odwrotna();
		break;
	default:
		printf("Cos poszlo nie tak ");
		break;

	}
}