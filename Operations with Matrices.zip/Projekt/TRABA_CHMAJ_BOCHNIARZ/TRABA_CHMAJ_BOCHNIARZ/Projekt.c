// sekcja dokumentacji
//Celem projektu jest przedstawienie operacji na macierzach i wektorach
//Sekcja dyrektyw preprocesora
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include "projekt.h"

#define N 3

//Funkcja alokujaca pamiec dla macierzy liczb calkowitych o zadanej liczbie wierszy i kolumn
int** allocate_matrix(int r, int c) {
	int** a = malloc(r * sizeof(*a));
	if (a == NULL) return NULL;
	for (int i = 0; i < r; ++i) {
		a[i] = malloc(c * sizeof(**a));
		if (a[i] == NULL) {
			for (int j = 0; j < i; ++j) {
				free(a[i]);
			}
			free(a);
			a = NULL;
			return NULL;
		}
	}
	return a;
}

//Funkcja zwalnia zalokowana pamiec przez funkcje allocate_matrix()
void free_matrix(int** a, int r) {
	if (a == NULL) {
		return;
	}
	for (int i = 0; i < r; ++i) {
		free(a[i]);
	}
	free(a);
	a = NULL;
}
void print_matrix(int** a, int r, int c) {
	for (int i = 0; i < r; ++i) {
		for (int j = 0; j < c; ++j) {
			printf("%4d, ", a[i][j]);
		}
		printf("\n");
	}
}

//Funkcja wypelnia macierz losowymi liczbami z przedzialu (-25,25)
void wypelnianie_macierzy(int** a, int r, int c) {
	srand(time(NULL));
	for (int i = 0; i < r; ++i) {
		for (int j = 0; j < c; ++j) {
			a[i][j] = rand() % 51 - 25;
		}
	}

}

void wypelnianie_macierzy_test() {
	int r, c;
	printf("Podaj liczbe wierszy macierzy: ");
	if (scanf_s("%d", &r) < 1) {
		printf("Blad danych!");
		return;
	}
	printf("Podaj liczbe kolumn macierzy: ");
	if (scanf_s("%d", &c) < 1) {
		printf("Blad danych!");
		return;
	}
	int** a = allocate_matrix(r, c);
	if (a == NULL) {
		printf("Blad alokacji pamieci!");
		return;
	}
	wypelnianie_macierzy(a, r, c);
	printf("Wygenerowana losowo tablica: \n");
	for (int i = 0; i < r; ++i) {
		for (int j = 0; j < c; ++j) {

			printf("%4d ", a[i][j]);
		}
		printf("\n");

	}
}
//Funkcja ktora wypisuje najwiekszy element w kazdym wierszu i podaje jego indeks
void najwiekszy_element(int** a, int r, int c) {
	for (int i = 0; i < r; ++i) {
		int max_element = a[i][0];
		int max_indeks = 0;
		for (int j = 0; j < c; ++j) {
			if (a[i][j] > max_element) {
				max_element = a[i][j];
				max_indeks = j;
			}

		}
		printf("Najwiekszy element w %d wierszu to %d (indeks: [%d][%d])\n", i + 1, max_element, i + 1, max_indeks + 1);
	}
}
void najwiekszy_element_test() {
	int r, c;
	printf("Podaj liczbe wierszy macierzy: ");
	if (scanf_s("%d", &r) < 1) {
		printf("Blad danych!");
		return;
	}
	printf("Podaj liczbe kolumn macierzy: ");
	if (scanf_s("%d", &c) < 1) {
		printf("Blad danych!");
		return;
	}
	int** a = allocate_matrix(r, c);
	if (a == NULL) {
		printf("Blad alokacji pamieci!");
		return;
	}
	wypelnianie_macierzy(a, r, c);
	printf("Wygenerowana losowo tablica: \n");
	for (int i = 0; i < r; ++i) {
		for (int j = 0; j < c; ++j) {

			printf("%4d ", a[i][j]);
		}
		printf("\n");

	}
	najwiekszy_element(a, r, c);
}

double wyznacznik_macierzy(int** a, int r, int c) {
	double det = 1;
	double ratio;
	for (int i = 0; i < r; ++i) {
		for (int j = i + 1; j < r; ++j) {
			if (a[i][i] == 0) {
				return 0;
			}
			ratio = a[j][i] / a[i][i];
			for (int k = i; k < c; ++k) {
				a[j][k] -= ratio * a[i][k];
			}
		}
	}
	for (int i = 0; i < r; ++i) {
		det *= a[i][i];
	}
	return det;
}

//Funkcja obliczajaca wyznacznik macierzy wedlug rekurencyjnego rozwiniecia Laplace'a

// Funkcja pomocnicza do tworzenia podmacierzy o wymiarach (n-1)x(n-1)
void create_submatrix(int** a, int** submatrix, int i, int j, int n) {
	int x = 0, y = 0;
	for (int r = 0; r < n; ++r) {
		for (int c = 0; c < n; ++c) {
			if (r != i && c != j) {
				submatrix[x][y++] = a[r][c];
				if (y == n - 1) {
					y = 0;
					x++;
				}
			}
		}
	}
}

// Funkcja obliczajaca wyznacznik macierzy wg rekurencyjnego rozwiniecia Laplace'a
double determinant(int** a, int r) {
	int det = 0;
	if (r == 1) {
		// Przypadek bazowy - macierz 1x1
		det = a[0][0];
	}
	else if (r == 2) {
		// Przypadek bazowy - macierz 2x2
		det = a[0][0] * a[1][1] - a[0][1] * a[1][0];
	}
	else {
		// Rekurencyjne rozwijanie wzgledem pierwszego wiersza
		for (int j = 0; j < r; j++) {
			// Tworzenie podmacierzy
			int** submatrix = malloc((r - 1) * sizeof(int*));
			for (int i = 0; i < r - 1; i++) {
				submatrix[i] = malloc((r - 1) * sizeof(int));
			}
			create_submatrix(a, submatrix, 0, j, r);
			// Obliczanie wyznacznika podmacierzy i dodawanie do sumy
			det += ((j % 2 == 0) ? 1 : -1) * a[0][j] * determinant(submatrix, r - 1);
			// Zwolnienie pamieci zaalokowanej na podmacierz
			for (int i = 0; i < r - 1; i++) {
				free(submatrix[i]);
			}
			free(submatrix);
		}
	}
	return det;
}

void wyznacznik_macierzy_test() {
	int r, c;
	printf("Podaj liczbe wierszy macierzy: ");
	if (scanf_s("%d", &r) < 1) {
		printf("Blad danych!");
		return;
	}
	printf("Podaj liczbe kolumn macierzy: ");
	if (scanf_s("%d", &c) < 1) {
		printf("Blad danych!");
		return;
	}
	int** a = allocate_matrix(r, c);
	if (a == NULL) {
		printf("Blad alokacji pamieci!");
		return;
	}
	wypelnianie_macierzy(a, r, c);
	printf("Wygenerowana losowo macierz: \n");
	for (int i = 0; i < r; ++i) {
		for (int j = 0; j < c; ++j) {

			printf("%4d ", a[i][j]);
		}
		printf("\n");

	}
	if (r != c) {
		printf("Nie mozna policzyc wyznacznika, macierz musi byc kwadratowa!\n");

	}
	else {
		printf("Wyznacznik macierzy wynosi: %f\n", determinant(a, r));
	}
}

//Funkcja ktora oblicza liczbe wystapien danej liczby w macierzy
int liczba_wystapien(int** a, int r, int c, int x) {
	int licznik = 0;
	for (int i = 0; i < r; ++i) {
		for (int j = 0; j < c; ++j) {
			if (a[i][j] == x) {
				licznik++;
			}
		}
	}
	return licznik;
}

void liczba_wystapien_test() {
	int r, c, x;
	printf("Podaj liczbe wierszy macierzy: ");
	if (scanf_s("%d", &r) < 1) {
		printf("Blad danych!");
		return;
	}
	printf("Podaj liczbe kolumn macierzy: ");
	if (scanf_s("%d", &c) < 1) {
		printf("Blad danych!");
		return;
	}
	printf("Podaj liczbe jaka chcesz sprawdzic: ");
	if (scanf_s("%d", &x) < 1) {
		printf("Blad danych!");
		return;
	}
	int** a = allocate_matrix(r, c);
	if (a == NULL) {
		printf("Blad alokacji pamieci!");
		return;
	}
	wypelnianie_macierzy(a, r, c);
	printf("Wygenerowana losowo tablica: \n");
	for (int i = 0; i < r; ++i) {
		for (int j = 0; j < c; ++j) {

			printf("%4d ", a[i][j]);
		}
		printf("\n");

	}
	int liczba = liczba_wystapien(a, r, c, x);
	printf("Liczba %d wystepuje w macierzy %d razy\n", x, liczba);
}

void zerowanie(int** a, int r, int c) {
	int mniejszy = (r < c) ? r : c;
	for (int i = 0; i < mniejszy; ++i) {
		for (int j = 0; j < c; ++j) {
			if (i == j || i + j == r - 1 || (i == r - 1 && j == 0)) {
				a[i][j] = 0;
			}
		}
	}
}
void zerowanie_test() {
	int r, c;
	printf("Podaj liczbe wierszy macierzy: ");
	if (scanf_s("%d", &r) < 1) {
		printf("Blad danych!");
		return;
	}
	printf("Podaj liczbe kolumn macierzy: ");
	if (scanf_s("%d", &c) < 1) {
		printf("Blad danych!");
		return;
	}
	if (r != c) {
		printf("To nie jest macierz kwadratowa");
	}
	else {
		int** a = allocate_matrix(r, c);
		if (a == NULL) {
			printf("Blad alokacji pamieci!");
			return;
		}
		wypelnianie_macierzy(a, r, c);
		printf("Wygenerowana losowo tablica: \n");
		for (int i = 0; i < r; ++i) {
			for (int j = 0; j < c; ++j) {

				printf("%4d ", a[i][j]);
			}
			printf("\n");

		}
		zerowanie(a, r, c);
		printf("\nMacierz po wywolaniu funkcji zerowania przekatnych: \n");
		for (int i = 0; i < r; ++i) {
			for (int j = 0; j < c; ++j) {
				printf("%4d ", a[i][j]);
			}
			printf("\n");
		}
	}
}
//Funkcja transpozycji macierzy
void transpose_matrix(int** a, int r, int c) {
	int** transposed = allocate_matrix(c, r);
	for (int i = 0; i < c; ++i) {
		for (int j = 0; j < r; ++j) {
			transposed[i][j] = a[j][i];
		}
	}
	printf("Macierz po transpozycji: \n");
	print_matrix(transposed, c, r);
	free_matrix(transposed, c);
}
void transpose_matrix_test() {
	int r, c;
	printf("Podaj liczbe wierszy macierzy: ");
	if (scanf_s("%d", &r) < 1) {
		printf("Blad danych!");
		return;
	}
	printf("Podaj liczbe kolumn macierzy: ");
	if (scanf_s("%d", &c) < 1) {
		printf("Blad danych!");
		return;
	}
	int** a = allocate_matrix(r, c);
	if (a == NULL) {
		printf("Blad alokacji pamieci!");
		return;
	}
	wypelnianie_macierzy(a, r, c);
	printf("Wygenerowana losowo macierz: \n");
	for (int i = 0; i < r; ++i) {
		for (int j = 0; j < c; ++j) {

			printf("%4d ", a[i][j]);
		}
		printf("\n");

	}
	transpose_matrix(a, r, c);
}
//Alokowanie pamieci na wektor 
int* allocate_vector(int n) {
	int* vector = malloc(n * sizeof(*vector));
	if (vector == NULL) {
		return NULL;
	}
	return vector;
}
int* allocate_result(int n) {
	int* result = malloc(n * sizeof(*result));
	if (result == NULL) {
		return NULL;
	}
	return result;
}
int* wypelnianie_wektora(int* vector, int n) {
	srand(time(NULL));
	for (int i = 0; i < n; ++i) {
		vector[i] = rand() % 10 - 15;
	}
	return vector;

}
int* wypelnianie_wektora2(int* vector, int* vector2, int n) {
	srand(time(NULL));
	for (int i = 0; i < n; ++i) {
		vector[i] = rand() % 10 - 15;
		vector2[i] = rand() % 15 - 25;
	}
	return vector;

}

//Funkcja mnozenia macierzy przez wektor
int* mnozenie_przez_wektor(int** a, int* vector, int* result, int r, int c) {
	for (int i = 0; i < r; i++) {
		result[i] = 0;
		for (int j = 0; j < c; j++) {
			result[i] += a[i][j] * vector[j];
		}
	}
	return result;
}

void mnozenie_przez_wektor_test() {
	int r, c, n;
	printf("Podaj liczbe wierszy macierzy: ");
	if (scanf_s("%d", &r) < 1) {
		printf("Blad danych!");
		return;
	}
	printf("Podaj liczbe kolumn macierzy: ");
	if (scanf_s("%d", &c) < 1) {
		printf("Blad danych!");
		return;
	}

	printf("Podaj rozmiar wektora: ");
	if (scanf_s("%d", &n) < 1) {
		printf("Blad danych!");
		return;
	}
	if (c != n) {
		printf("Nie mozna wykonac mnozenia. Liczba kolumn nie jest rowna dlugosci wektora");
	}
	else {
		int** a = allocate_matrix(r, c);
		if (a == NULL) {
			printf("Blad alokacji pamieci!");
			return;
		}
		wypelnianie_macierzy(a, r, c);
		printf("Wygenerowana losowo tablica: \n");
		for (int i = 0; i < r; ++i) {
			for (int j = 0; j < c; ++j) {

				printf("%4d ", a[i][j]);
			}
			printf("\n");

		}
		int* vector = allocate_vector(n);
		if (vector == NULL) {
			printf("Blad alokacji pamieci!");
			return;
		}
		int* result = allocate_vector(n);
		if (result == NULL) {
			printf("Blad alokacji pamieci!");
			return;
		}
		wypelnianie_wektora(vector, n);
		printf("Wektor x:\n");
		for (int i = 0; i < n; ++i) {
			printf("[ %4d ]\n", vector[i]);
		}
		mnozenie_przez_wektor(a, vector, result, r, c);
		printf("Wynik mnozenia macierzy przez wektor:\n");
		for (int i = 0; i < c; i++) {
			printf("[ %4d ]\n", result[i]);
		}

	}

}
void mnozenie_dwoch_wektorow(int* vector, int* vector2, int* result, int n) {
	for (int i = 0; i < n; ++i) {
		result[i] = vector[i] * vector2[i];
	}

}
void mnozenie_dwoch_wektorow_test() {
	int n, n2;
	printf("Podaj rozmiar pierwszego wektora: ");
	if (scanf_s("%d", &n) < 1) {
		printf("Blad danych!");
		return;
	}
	printf("Podaj rozmiar drugiego wektora: ");
	if (scanf_s("%d", &n2) < 1) {
		printf("Blad danych!");
		return;
	}
	if (n != n2) {
		printf("Wektory nie sa rownych rozmiarow. Nie mozna wykonac mnozenia");
	}
	else {
		int* vector = allocate_vector(n);
		int* vector2 = allocate_vector(n2);
		if (vector == NULL) {
			printf("Blad alokacji pamieci!");
			return;
		}
		wypelnianie_wektora(vector, n);
		printf("Wektor x1: ");
		printf("[ ");
		for (int i = 0; i < n; ++i) {
			printf("%4d ", vector[i]);
		}
		printf("] \n");
		if (vector2 == NULL) {
			printf("Blad alokacji pamieci!");
			return;
		}
		wypelnianie_wektora2(vector, vector2, n2);
		printf("Wektor x2: ");
		printf("[ ");
		for (int i = 0; i < n2; ++i) {
			printf("%4d ", vector[i]);
		}
		printf("] \n");

		int* result = allocate_vector(n);
		if (result == NULL) {
			printf("Blad alokacji pamieci!");
			return;
		}
		mnozenie_dwoch_wektorow(vector, vector2, result, n);
		printf("Wynik mnozenia dwoch wektorow: ");
		printf("[ ");
		for (int i = 0; i < n; ++i) {
			printf("%4d ", result[i]);
		}
		printf("] \n");

	}
}



// Funkcja mnozy macierze a i b o odpowiednich wymiarach r1 x c1 i r2 x c2
int** multiply_matrices(int** a, int** b, int r1, int c1, int r2, int c2) {
	if (c1 != r2) {
		return NULL; // Nie mozna pomnozyc macierzy o niezgodnych wymiarach
	}

	int** result = allocate_matrix(r1, c2);
	if (result == NULL) {
		return NULL; // blad alokacji pamieci dla macierzy wynikowej
	}

	for (int i = 0; i < r1; ++i) {
		for (int j = 0; j < c2; ++j) {
			result[i][j] = 0;
			for (int k = 0; k < c1; ++k) {
				result[i][j] += a[i][k] * b[k][j];
			}
		}
	}

	return result;
}


// Funkcja wypisuje macierz a o wymiarach r x c
void mnozenie_dwoch_macierzy(int** a, int r, int c) {
	for (int i = 0; i < r; ++i) {
		for (int j = 0; j < c; ++j) {
			printf("%4d, ", a[i][j]);
		}
		printf("\n");
	}
}

void mnozenie_dwoch_macierzy_test() {
	int r1, c1, r2, c2;



	printf("Podaj liczbe kolumn pierwszej macierzy: ");
	if (scanf_s("%d", &c1) != 1) {
		printf("Blad danych!");
		return;
	}

	printf("Podaj liczbe wierszy pierwszej macierzy: ");
	if (scanf_s("%d", &r1) != 1) {
		printf("Blad danych!");
		return;
	}


	printf("Podaj liczbe kolumn drugiej macierzy: ");
	if (scanf_s("%d", &c2) != 1) {
		printf("Blad danych!");
		return;
	}

	printf("Podaj liczbe wierszy drugiej macierzy: ");
	if (scanf_s("%d", &r2) != 1) {
		printf("Blad danych!");
		return;
	}


	if (c1 != r2) {
		printf("Nie mozna pomnozyc macierzy o podanych wymiarach!");
		return;
	}

	int** matrix1 = allocate_matrix(r1, c1);
	int** matrix2 = allocate_matrix(r2, c2);

	if (matrix1 == NULL || matrix2 == NULL) {
		printf("Blad alokacji pamieci!");
		free_matrix(matrix1, r1);
		free_matrix(matrix2, r2);
		return;
	}

	printf("Wypelnij pierwsza macierz:\n");
	wypelnianie_macierzy(matrix1, r1, c1);

	printf("Wypelnij druga macierz:\n");
	wypelnianie_macierzy(matrix2, r2, c2);

	printf("Pierwsza macierz:\n");
	print_matrix(matrix1, r1, c1);

	printf("Druga macierz:\n");
	print_matrix(matrix2, r2, c2);

	int** result = multiply_matrices(matrix1, matrix2, r1, c1, r2, c2);

	if (result == NULL) {
		printf("Nie mozna pomnozyc macierzy o podanych wymiarach!");
		free_matrix(matrix1, r1);
		free_matrix(matrix2, r2);
		return;
	}

	printf("Wynik mnozenia macierzy:\n");
	print_matrix(result, r1, c2);

	free_matrix(matrix1, r1);
	free_matrix(matrix2, r2);
	free_matrix(result, r1);

	return;
}

// Funkcja eliminacji Gaussa
#define EPS 1e-12

int gauss(int n, double** AB, double* X) {
	int i, j, k;
	double m, s;

	for (i = 0; i < n - 1; i++) {
		for (j = i + 1; j < n; j++) {
			if (fabs(AB[i][i]) < EPS)
				return 0;
			m = -AB[j][i] / AB[i][i];
			for (k = i + 1; k <= n; k++)
				AB[j][k] += m * AB[i][k];
		}
	}

	for (i = n - 1; i >= 0; i--) {
		s = AB[i][n];
		for (j = n - 1; j >= i + 1; j--)
			s -= AB[i][j] * X[j];
		if (fabs(AB[i][i]) < EPS)
			return 0;
		X[i] = s / AB[i][i];
	}

	return 1;
}

void test_rownanie_macierzowe() {
	double** AB, * X;
	int n, i, j;

	printf("Podaj liczbe niewiadomych: ");
	scanf_s("%d", &n);
	AB = (double**)malloc(n * sizeof(double*));
	X = (double*)malloc(n * sizeof(double));
	for (i = 0; i < n; i++)
		AB[i] = (double*)malloc((n + 1) * sizeof(double));
	printf("Podaj dane dla macierzy AB:\n");
	for (i = 0; i < n; i++) {
		for (j = 0; j <= n; j++) {
			scanf_s("%lf", &AB[i][j]);
		}
	}
	if (gauss(n, AB, X)) {
		for (i = 0; i < n; i++) {
			printf("x%d = %.4lf\n", i + 1, X[i]);
		}
	}
	else {
		printf("DZIELNIK ZERO\n");
	}
	for (i = 0; i < n; i++) {
		free(AB[i]);
	}
	free(AB);
	free(X);
}


// Funkcja obliczania wartosci wlasnych macierzy
void oblicz_wartosci_wlasne(int** macierz, int size) {
	int i, j, iteracje, max_iteracje;
	float epsilon, norma, suma, lambda, lambda_poprzednie;
	// inicjalizacje wektorow
	int* wektor = allocate_vector(size);
	int* wektor_poprzedni = allocate_vector(size);
	for (i = 0; i < size; i++) {
		wektor[i] = 1.0;
	}
	epsilon = 1e-6;  // Dok�adno�� oblicze�
	// iteracje metody potegowej
	max_iteracje = 1000;  // Maksymalna liczba iteracji
	iteracje = 0;
	norma = 1.0;
	lambda = 0.0;
	while (norma > epsilon && iteracje < max_iteracje) {
		iteracje++;
		// Obliczanie wektora kolejnego przybli�enia
		for (i = 0; i < size; i++) {
			wektor_poprzedni[i] = wektor[i];
			wektor[i] = 0.0;
			for (j = 0; j < size; j++) {
				wektor[i] += macierz[i][j] * wektor_poprzedni[j];
			}
		}
		// Obliczanie warto�ci w�asnej
		suma = 0.0;
		for (i = 0; i < size; i++) {
			suma += wektor[i] * wektor[i];
		}
		norma = sqrt(suma);
		// Normalizacja wektora
		for (i = 0; i < size; i++) {
			wektor[i] /= norma;
		}
		// Obliczanie warto�ci w�asnej
		lambda_poprzednie = lambda;
		lambda = 0.0;
		for (i = 0; i < size; i++) {
			lambda += wektor[i] * wektor_poprzedni[i];
		}
	}
	free(wektor);
	free(wektor_poprzedni);
	if (iteracje >= max_iteracje) {
		printf("Nie udalo sie obliczyc wartosci wlasnej w podanej liczbie iteracji.\n");
		return;
	}
	else {
		printf("Wartosc wlasna: %.2f\n", lambda);
	}
}

void test_wartosci_wlasne()
{
	int r, c;
	printf("Podaj liczbe wierszy macierzy: ");
	scanf_s("%d", &r);
	printf("Podaj liczbe kolumn macierzy: ");
	scanf_s("%d", &c);
	int** a = allocate_matrix(r, c);
	int i;
	for (i = 0; i < r; i++) {
		a[i] = (int*)malloc(c * sizeof(int));
	}
	wypelnianie_macierzy(a, r, c);
	print_matrix(a, r, c);
	oblicz_wartosci_wlasne(a, r);
	for (i = 0; i < r; i++) {
		free(a[i]);
	}
	free(a);
	return;
}

// Funkcja do zamiany macierzy na macierz jednostkow�
void zamien_na_macierz_jednostkowa(int** a, int** macierz_jednostkowa, int size) {
	// Skopiuj macierz do macierzy jednostkowej
	for (int i = 0; i < size; i++) {
		for (int j = 0; j < size; j++) {
			macierz_jednostkowa[i][j] = a[i][j];
		}
	}

	// Zamie� macierz jednostkow�
	for (int i = 0; i < size; i++) {
		for (int j = 0; j < size; j++) {
			if (i == j) {
				macierz_jednostkowa[i][j] = 1.0;
			}
			else {
				macierz_jednostkowa[i][j] = 0.0;
			}
		}
	}
}

// Funkcja do zamiany wierszy macierzy
void zamien_wiersze(int** a, int row1, int row2, int size) {
	for (int j = 0; j < size; j++) {
		float temp = a[row1][j];
		a[row1][j] = a[row2][j];
		a[row2][j] = temp;
	}
}

// Funkcja do mno�enia wiersza macierzy przez skalar
void pomnoz_wiersz_przez_skalar(int** a, int row, float skalar, int size) {
	for (int j = 0; j < size; j++) {
		a[row][j] *= skalar;
	}
}

// Funkcja do odejmowania wiersza od innego wiersza macierzy
void odejmij_wiersz_od_innego(int** a, int row1, int row2, float wspolczynnik, int size) {
	for (int j = 0; j < size; j++) {
		a[row1][j] -= wspolczynnik * a[row2][j];
	}
}

// Funkcja do obliczania macierzy odwrotnej
int oblicz_macierz_odwrotna(int** a, int** macierz_jednostkowa, int size) {
	// Skopiuj macierz do macierzy jednostkowej
	zamien_na_macierz_jednostkowa(a, macierz_jednostkowa, size);
	// Zastosuj eliminacj� Gaussa-Jordana
	for (int k = 0; k < size; k++) {
		// Szukaj najwi�kszego elementu w kolumnie
		int maxIndex = k;
		float maxValue = a[k][k];
		for (int i = k + 1; i < size; i++) {
			if (a[i][k] > maxValue) {
				maxIndex = i;
				maxValue = a[i][k];
			}
		}
		// Je�li najwi�kszy element w kolumnie jest r�wny zero, macierz nie jest odwracalna
		if (maxValue == 0.0) {
			return 0;
		}
		// Zamie� wiersze, aby najwi�kszy element znalaz� si� na diagonali
		zamien_wiersze(a, k, maxIndex, size);
		zamien_wiersze(macierz_jednostkowa, k, maxIndex, size);
		// Znormalizuj wiersz na diagonali
		float diagonalValue = a[k][k];
		pomnoz_wiersz_przez_skalar(a, k, 1.0 / diagonalValue, size);
		pomnoz_wiersz_przez_skalar(macierz_jednostkowa, k, 1.0 / diagonalValue, size);
		// Odejmij krotno�� wiersza na diagonali od pozosta�ych wierszy
		for (int i = 0; i < size; i++) {
			if (i != k) {
				float wspolczynnik = a[i][k];
				odejmij_wiersz_od_innego(a, i, k, wspolczynnik, size);
				odejmij_wiersz_od_innego(macierz_jednostkowa, i, k, wspolczynnik, size);
			}
		}
	}

	return 1;
}

void test_macierz_odwrotna()
{
	int r, c;
	printf("Podaj liczbe wierszy macierzy: \n");
	scanf_s("%d", &r);
	printf("Podaj liczbe kolumn macierzy: \n");
	scanf_s("%d", &c);
	if (r != c) {
		printf("Macierz musi byc kwadratowa\n");
		return;
	}
	// Alokacja pami�ci dla macierzy
	int** a = allocate_matrix(r, c);
	int** macierzOdwrotna = allocate_matrix(r, c);
	printf("Podaj elementy macierzy:\n");
	for (int i = 0; i < r; i++) {
		for (int j = 0; j < r; j++) {
			printf("Podaj element [%d][%d]: ", i, j);
			scanf_s("%d", &a[i][j]);
		}
	}
	// Obliczanie macierzy odwrotnej
	if (oblicz_macierz_odwrotna(a, macierzOdwrotna, r)) {
		printf("\nMacierz odwrotna:\n");
		print_matrix(macierzOdwrotna, r, c);
	}
	else {
		printf("\nPodana macierz nie ma odwrotno�ci.\n");
	}
	// Zwalnianie pami�ci macierzy
	free_matrix(a, r);
	free_matrix(macierzOdwrotna, r);
}